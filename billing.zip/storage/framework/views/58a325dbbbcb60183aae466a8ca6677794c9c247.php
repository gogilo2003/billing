<!DOCTYPE html>
<html lang="<?php echo e(config('app.locale')); ?>">
<head>
    <meta charset="UTF-8">
    <title><?php echo e(config('app.name')); ?></title>
    <style type="text/css">
        @import  url('http://fonts.googleapis.com/css?family=Poiret+One&display=swap');
        @import  url('http://fonts.googleapis.com/css?family=Poppins:300,600&display=swap');
        @import  url('<?php echo asset('css/pdf.min.css'); ?>');
    </style>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>
    <div class="title">
        <h4>
            <?php echo $__env->yieldContent('title'); ?>
        </h4>
    </div>
    <div class="wrapper">
        <div class="container">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
</body>
</html>
<?php /**PATH /var/www/billing/resources/views/layouts/pdf.blade.php ENDPATH**/ ?>