<?php $__env->startSection('title'); ?>
	Invoices
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar_left'); ?>
	##parent-placeholder-e1509e9f851d384310b95d9c4a49c4d7e924ac18##
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="card">
		<div class="card-header">
			<h4 class="card-title">Invoices</h4>
			<?php if($client): ?>
				<p class="category"><?php echo e($client->name); ?></p>
			<?php else: ?>
				<p class="category">List of Invoices</p>
			<?php endif; ?>
		</div>
		<div class="card-body">
            <a href="JavaScript:" class="btn btn-primary rounded-pill" data-toggle="modal" data-target="#mergeInvoicesModal">Merge Invoices</a>
            <hr>
			<table class="table table-hover table-striped" id="invoicesDataTable">
				<thead>
					<tr class="d-sm-table-row d-none">
						<th colspan="2">#</th>
						<th>Client</>
						<th>Name</th>
                        <th>Date</th>
						<th class="text-right">Amount</th>
						<th>&nbsp;</th>
					</tr>
				</thead>
				<tbody>
					<?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr class="d-sm-table-row d-flex flex-column">
						<td><?php echo e($loop->iteration); ?></td>
                        <td>
                            <div class="form-check form-check-inline">
                                <input id="tbl_invoice-<?php echo e($loop->iteration); ?>" class="form-check-input" type="checkbox" name="invoices" value="<?php echo e($invoice->id); ?>">
                            </div>
                        </td>
						<td><?php echo e($invoice->client->name); ?></td>
						<td><?php echo e($invoice->name); ?></td>
                        <td><?php echo e($invoice->created_at->format('D, d-M-Y')); ?></td>
						<td class="text-right"><?php echo e(number_format($invoice->amount(),2)); ?></td>
						<td>
							<a href="<?php echo e(route('invoices-view',$invoice->id)); ?>" class="btn btn-primary btn-sm rounded-pill"><i class="fas fa-th"></i>&nbsp;View</a>
							<a href="<?php echo e(route('invoices-download',$invoice->id)); ?>" class="btn btn-primary btn-sm rounded-pill"><i class="fas fa-file-download"></i>&nbsp;Download</a>
							<a href="<?php echo e(route('invoices-delivery',$invoice->id)); ?>" class="btn btn-primary btn-sm rounded-pill"><i class="fas fa-file-download"></i>&nbsp;Delivery</a>
						</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
		</div>
    </div>

    <div id="mergeInvoicesModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="mergeInvoicesModalTitle" aria-hidden="true" data-backdrop="static">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-xl" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="mergeInvoicesModalTitle">Merge Invoices</h5>
                    <button class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p>Accounts</p>
                    <ul class="list-group">
                        <?php $__currentLoopData = $invoices->sortBy('name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item">
                            <div class="form-check form-check-inline">
                                <input id="invoice-<?php echo e($loop->iteration); ?>" class="form-check-input" type="checkbox" name="invoices" value="<?php echo e($invoice->id); ?>">
                                <label for="invoice-<?php echo e($loop->iteration); ?>" class="form-check-label"><?php echo e($invoice->client->name); ?> >> <?php echo e($invoice->name); ?></label>
                            </div>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-primary rounded-pill" type="button" id="mergerInvoicesButton">Merge</button>
                    <button class="btn btn-danger rounded-pill" type="button" data-dismiss="modal">Cancel</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar'); ?>
    <li class="nav-item <?php echo e(is_current_path(route('invoices-create'),true)); ?>">
        <a class="nav-link waves-effect" href="<?php echo e(route('invoices-create')); ?>">
            <span class="fas fa-plus-circle"></span>
            Invoice
        </a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
	<style>

	</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts_top'); ?>
	<script type="text/javascript">

	</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts_bottom'); ?>
    <script type="text/javascript">
        let invoices = [];
		$('#invoicesDataTable').dataTable();
        $('#mergerInvoicesButton').click(function(e){
            let data = {
                _token: token,
                invoices
            }

            let url = '<?php echo e(route('invoices-merge-post')); ?>'

            $.post(url,data).then(
                response=>{console.log(response)},
                error=>{console.error(error)}
            )
        })
	</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', ['pageSlug' => 'invoices'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/billing/resources/views/invoices/index.blade.php ENDPATH**/ ?>