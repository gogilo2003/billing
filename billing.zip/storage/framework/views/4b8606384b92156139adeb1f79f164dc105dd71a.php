<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <table id="smsDataTable" class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Message Id</th>
                    <th>Recepient</th>
                    <th>Message</th>
                    <th>Status</th>
                    <th>Send Time</th>
                    <th>Sender Name</th>
                    <th>SMS Units</th>
                    <th>Network Name</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($message->message_id); ?></td>
                    <td><?php echo e($message->recepient); ?></td>
                    <td><?php echo e($message->message); ?></td>
                    <td><?php echo e($message->status); ?></td>
                    <td><?php echo e($message->send_time); ?></td>
                    <td><?php echo e($message->sender_name); ?></td>
                    <td><?php echo e($message->sms_unit); ?></td>
                    <td><?php echo e($message->network_name); ?></td>
                    <td></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        $('#smsDataTable').dataTable()
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app',['pageSlug'=>'messages','page'=>'Messages'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/billing/resources/views/messages/index.blade.php ENDPATH**/ ?>