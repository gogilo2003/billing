<?php $__env->startSection('title'); ?>
	Domains
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar_left'); ?>
	##parent-placeholder-e1509e9f851d384310b95d9c4a49c4d7e924ac18##
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <domains/>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(mix('js/app.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', ['pageSlug' => 'domains'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/billing/resources/views/domains/index.blade.php ENDPATH**/ ?>