<div class="sidebar">
    <div class="sidebar-wrapper">
        <div class="logo">
            <a href="<?php echo e(route('home')); ?>" class="simple-text logo-mini"><img src="<?php echo e(asset('favicon.png')); ?>"></a>
            <a href="<?php echo e(route('home')); ?>" class="simple-text logo-normal"><?php echo e(_('BILLING')); ?></a>
        </div>
        <ul class="nav">

            <li <?php if($pageSlug == 'dashboard'): ?> class="active " <?php endif; ?>>
                <a href="<?php echo e(route('home')); ?>">
                    <i class="tim-icons icon-chart-pie-36"></i>
                    <p><?php echo e(_('Dashboard')); ?></p>
                </a>
            </li>

            <li>
                <a data-toggle="collapse" href="#navbar-clients" aria-expanded="false">
                    <i class="fas fa-users" ></i>
                    <span class="nav-link-text" ><?php echo e(__('Clients')); ?></span>
                    <b class="caret mt-1"></b>
                </a>

                <div class="collapse" id="navbar-clients">
                    <ul class="nav pl-4">
                        <li <?php if($pageSlug == 'clients'): ?> class="active " <?php endif; ?>>
                            <a href="<?php echo e(route('clients')); ?>">
                                <i class="tim-icons icon-bullet-list-67"></i>
                                <p><?php echo e(_('List')); ?></p>
                            </a>
                        </li>
                        <li <?php if($pageSlug == 'clients/create'): ?> class="active " <?php endif; ?>>
                            <a href="<?php echo e(route('clients-create')); ?>">
                                <i class="tim-icons icon-simple-add"></i>
                                <p><?php echo e(_('New')); ?></p>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>

            <li>
                <a data-toggle="collapse" href="#navbar-accounts" aria-expanded="false">
                    <i class="tim-icons icon-bank" ></i>
                    <span class="nav-link-text" ><?php echo e(__('Accounts')); ?></span>
                    <b class="caret mt-1"></b>
                </a>

                <div class="collapse" id="navbar-accounts">
                    <ul class="nav pl-4">
                        <li <?php if($pageSlug == 'accounts'): ?> class="active " <?php endif; ?>>
                            <a href="<?php echo e(route('accounts')); ?>">
                                <i class="tim-icons icon-bullet-list-67"></i>
                                <p><?php echo e(_('List')); ?></p>
                            </a>
                        </li>
                        <li <?php if($pageSlug == 'accounts/create'): ?> class="active " <?php endif; ?>>
                            <a href="<?php echo e(route('accounts-create')); ?>">
                                <i class="tim-icons icon-simple-add"></i>
                                <p><?php echo e(_('New')); ?></p>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>

            <li>
                <a data-toggle="collapse" href="#navbar-invoices" aria-expanded="false">
                    <i class="tim-icons icon-paper" ></i>
                    <span class="nav-link-text" ><?php echo e(__('Invoices')); ?></span>
                    <b class="caret mt-1"></b>
                </a>

                <div class="collapse" id="navbar-invoices">
                    <ul class="nav pl-4">
                        <li <?php if($pageSlug == 'invoices'): ?> class="active " <?php endif; ?>>
                            <a href="<?php echo e(route('invoices')); ?>">
                                <i class="tim-icons icon-bullet-list-67"></i>
                                <p><?php echo e(_('List')); ?></p>
                            </a>
                        </li>
                        <li <?php if($pageSlug == 'invoices/create'): ?> class="active " <?php endif; ?>>
                            <a href="<?php echo e(route('invoices-create')); ?>">
                                <i class="tim-icons icon-simple-add"></i>
                                <p><?php echo e(_('New')); ?></p>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>

            <li>
                <a data-toggle="collapse" href="#navbar-messages" aria-expanded="false">
                    <i class="tim-icons icon-chat-33" ></i>
                    <span class="nav-link-text" ><?php echo e(__('Messages')); ?></span>
                    <b class="caret mt-1"></b>
                </a>

                <div class="collapse" id="navbar-messages">
                    <ul class="nav pl-4">
                        <li <?php if($pageSlug == 'messages'): ?> class="active " <?php endif; ?>>
                            <a href="<?php echo e(route('messages')); ?>">
                                <i class="tim-icons icon-bullet-list-67"></i>
                                <p><?php echo e(_('List')); ?></p>
                            </a>
                        </li>
                        <li <?php if($pageSlug == 'messages/create'): ?> class="active " <?php endif; ?>>
                            <a href="<?php echo e(route('messages-create')); ?>">
                                <i class="tim-icons icon-email-85"></i>
                                <p><?php echo e(_('Create Message')); ?></p>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>

            <li <?php if($pageSlug == 'domains'): ?> class="active " <?php endif; ?>>
                <a href="<?php echo e(route('domains')); ?>">
                    <i class="tim-icons icon-world"></i>
                    <p><?php echo e(_('Domains')); ?></p>
                </a>
            </li>

            <li <?php if($pageSlug == 'setup'): ?> class="active " <?php endif; ?>>
                <a href="<?php echo e(route('setup')); ?>">
                    <i class="tim-icons icon-settings"></i>
                    <p><?php echo e(_('Setup')); ?></p>
                </a>
            </li>

        </ul>
    </div>
</div>
<?php /**PATH /var/www/billing/resources/views/layouts/navbars/sidebar.blade.php ENDPATH**/ ?>