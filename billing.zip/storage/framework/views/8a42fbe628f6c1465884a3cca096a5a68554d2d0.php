<?php $__env->startSection('content'); ?>
    <div>
        <a href="#" class="btn btn-primary rounded-pill" data-toggle="modal" data-target="#migrateDialog"><span class="fa fa-cogs"></span>&nbsp;&nbsp; Run Migration</a>
    </div>
    <hr>
    <div id="setup_results"></div>
    <?php echo $__env->make('setup.migrate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    Setup
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['pageSlug' => 'setup'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/billing/resources/views/setup/index.blade.php ENDPATH**/ ?>