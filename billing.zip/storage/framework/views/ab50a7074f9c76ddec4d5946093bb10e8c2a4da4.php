<?php $__env->startSection('title'); ?>
	Accounts
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar_left'); ?>
	##parent-placeholder-e1509e9f851d384310b95d9c4a49c4d7e924ac18##
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="card">
		<div class="card-header">
			<h3 class="card-title">Accounts</h3>
			<p class="category">Accounts for <?php echo e(isset($client) ? $client->name : 'all clients'); ?></p>
		</div>
		<div class="card-body">
			<table class="table table-hover table-striped" id="accountsDataTable">
				<thead>
					<tr class="d-sm-table-row d-none">
                        <th>#</th>
                        <?php if(!isset($client)): ?>
                        <th>Client Name</th>
                        <?php endif; ?>
						<th>Name</th>
						<th>Notification</th>
						<th class="text-right">Credit</th>
						<th class="text-right">Debit</th>
						<th class="text-right">Balance</th>
						<th></th>
					</tr>
				</thead>
				<tbody>
					<?php $__currentLoopData = $accounts->sortBy('balance'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr class="d-sm-table-row d-flex flex-column">
                        <td><?php echo e($loop->iteration); ?></td>
                        <?php if(!isset($client)): ?>
						<td><?php echo e($account->client->name); ?></td>
                        <?php endif; ?>
						<td><?php echo e($account->name); ?></td>
						<td><?php echo e($account->notification ? 'Enabled' : 'Disabled'); ?></td>
						<td><span class="d-none d-sm-inline-block" style="width: 180px">Credit: </span><?php echo e(number_format($account->cr(),2)); ?></td>
						<td><span class="d-none d-sm-inline-block" style="width: 180px">Debit: </span><?php echo e(number_format($account->dr(),2)); ?></td>
						<td><span class="d-none d-sm-inline-block" style="width: 180px">Balance: </span><?php echo e(number_format($account->balance(),2)); ?></td>
						<td>
                            <div class="dropdown">
                                <button class="btn btn-outline-primary btn-sm rounded-pill dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="tim-icons icon-settings"></i>
                                </button>
                                <div class="dropdown-menu dropdown-primary">
                                    <a href="<?php echo e(route('accounts-edit',$account->id)); ?>" class="dropdown-item"><i class="tim-icons icon-pencil"></i>&nbsp;Edit</a>
                                    <a href="<?php echo e(route('accounts-view',$account->id)); ?>" class="dropdown-item"><i class="fas fa-th"></i>&nbsp;View</a>
                                    <a href="<?php echo e(route('accounts-transaction',$account->id)); ?>" class="dropdown-item"><i class="fas fa-plus-circle"></i>&nbsp;Transaction</a>
                                    <a href="<?php echo e(route('accounts-transactions',$account->id)); ?>" class="dropdown-item"><i class="tim-icons icon-coins"></i>&nbsp;Transactions</a>
                                    <a href="<?php echo e(route('invoices-create',$account->client->id)); ?>" class="dropdown-item"><i class="tim-icons icon-paper"></i>&nbsp;New Invoice</a>
                                    <a href="<?php echo e(route('accounts-download',$account->id)); ?>" class="dropdown-item"><i class="tim-icons icon-cloud-download-93"></i>&nbsp;Download</a>
                                    <a href="JavaScript:updateNotification(<?php echo e($account->id); ?>)" class="dropdown-item"><i class="tim-icons icon-bell-55"></i>&nbsp;Notification</a>
                                </div>
                            </div>
						</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar'); ?>
	##parent-placeholder-c63e3c1cfa2ff651ad4cfadea3e21265ffcf8ca3##
	<li class="nav-item">
		<a class="nav-link" href="<?php echo e(route('accounts-create')); ?>">
			New Account
		</a>
	</li>
	<li class="nav-item">
		<a class="nav-link" href="<?php echo e(route('invoices-create')); ?>">
			New Invoice
		</a>
	</li>
	<li class="nav-item">
		<a class="nav-link" href="<?php echo e(route('accounts-transaction')); ?>">
			New Transaction
		</a>
	</li>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
	<style>

	</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts_top'); ?>
	<script type="text/javascript">

	</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts_bottom'); ?>
	<script type="text/javascript">
        function updateNotification(id){
            $.post('<?php echo e(route("api-accounts-notification-update")); ?>',{id}).then(response=>{
                alert(response.message)
            })
        }
		$('table#accountsDataTable').dataTable()
	</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', ['pageSlug' => 'accounts'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/billing/resources/views/accounts/index.blade.php ENDPATH**/ ?>