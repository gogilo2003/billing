<?php $__env->startSection('title'); ?>
	Clients
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar_left'); ?>
	##parent-placeholder-e1509e9f851d384310b95d9c4a49c4d7e924ac18##
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-md-12">
	        <div class="card">
	            <div class="card-header">
	                <h4 class="cart-title">Clients</h4>
	                <p class="category">List of all registered clients</p>
	            </div>
	            <div class="card-body">
	                <table class="table table-hover table-striped" id="clientsDataTable">
	                    <thead>
                            <tr class="d-sm-table-row d-none">
                                <th>#</th>
                                <th>Name</th>
                                <th>Phone</th>
                                <th>Balance</th>
                                <th></th>
                            </tr>
	                    </thead>
	                    <tbody>
	                        <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                        <tr class="d-sm-table-row d-flex flex-column">
	                        	<td><?php echo e($loop->iteration); ?></td>
	                        	<td><?php echo e(strtoupper($client->name)); ?></td>
	                        	<td><?php echo e($client->phone); ?></td>
	                        	<td>Kshs <?php echo e(number_format($client->balance,2)); ?></td>
	                        	<td>
                                    <div class="dropdown">
                                        <button class="btn btn-outline-primary rounded-pill dropdown-toggle btn-sm" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <i class="fas fa-tools"></i>
                                            Manage
                                        </button>
                                        <div class="dropdown-menu dropdown-primary">
                                            <a href="<?php echo e(route('clients-edit',$client->id)); ?>" class="dropdown-item"><i class="fas fa-edit"></i>&nbsp;Edit</a>
                                            <a href="<?php echo e(route('clients-view',$client->id)); ?>" class="dropdown-item"><i class="fas fa-th"></i>&nbsp;View</a>
                                            <a href="<?php echo e(route('clients-download',$client->id)); ?>" class="dropdown-item"><i class="fas fa-file-download"></i>&nbsp;Download</a>
                                            <a href="<?php echo e(route('accounts',$client->id)); ?>" class="dropdown-item"><i class="fas fa-university"></i>&nbsp;Accounts</a>
                                            <a href="<?php echo e(route('invoices',$client->id)); ?>" class="dropdown-item"><i class="fas fa-file-invoice"></i>&nbsp;Invoices</a>
                                            <a href="javascript:deleteClient" class="dropdown-item"><i class="fas fa-trash"></i>&nbsp;Delete</a>
                                        </div>
                                    </div>

	                        	</td>
	                        </tr>
	                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                    </tbody>
	                </table>

	            </div>
	        </div>
	    </div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar'); ?>
	##parent-placeholder-c63e3c1cfa2ff651ad4cfadea3e21265ffcf8ca3##
	<li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('clients-create')); ?>">
            <i class="fas fa-plus-circle"></i>
			New Client
		</a>
	</li>
	<li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('accounts')); ?>">
            <i class="fas fa-university"></i>
			Accounts
		</a>
	</li>
	<li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('invoices')); ?>">
            <i class="fas fa-file-invoice"></i>
			Invoices
		</a>
	</li>
	<li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('clients-clients-download')); ?>">
            <i class="fas fa-file-download"></i>
			Download
		</a>
	</li>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
	<style>

	</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts_top'); ?>
	<script type="text/javascript">

	</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts_bottom'); ?>
	<script type="text/javascript">
		$('#clientsDataTable').dataTable()
	</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', ['pageSlug' => 'clients'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/billing/resources/views/clients/index.blade.php ENDPATH**/ ?>