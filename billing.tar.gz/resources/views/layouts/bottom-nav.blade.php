<nav class="pull-left">
    <ul>
        <li>
            <a href="{{ url('/') }}">
                Home
            </a>
        </li>
        <li>
            <a href="#">
                Company
            </a>
        </li>
        <li>
            <a href="#">
                Portfolio
            </a>
        </li>
        <li>
            <a href="#">
               Blog
            </a>
        </li>
    </ul>
</nav>
