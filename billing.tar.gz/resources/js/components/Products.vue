<template>
    <div class="row">
        <div class="col-md-4">
            <product-categories/>
        </div>
        <div class="col-md-8"></div>
    </div>
</template>
<script>
import ProductCategories from './ProductCategories.vue'
export default {
    components:{
        ProductCategories
    }
}
</script>
